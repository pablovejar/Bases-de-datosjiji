create view tour_region(tid, rid) as
SELECT t.tid,
       a.rid
FROM agencia a,
     tour t
WHERE (a.aid = t.aid);

alter table tour_region
    owner to grupo47;

